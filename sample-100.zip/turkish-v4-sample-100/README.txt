100 inspection examples selected from v4 TRAIN only; not an independent evaluation set. Preserve the supplied license and Wikipedia attribution.
