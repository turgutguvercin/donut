import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
root=Path('/workspace/turkish-recognition-200k-v4')
targets=[(family,style) for family in ('Times New Roman','Arial') for style in ('regular','bold','italic','bold_italic')]
selected={}
with (root/'metadata.jsonl').open() as source:
    for line in source:
        row=json.loads(line)
        c=row['categories']
        key=(c['font_family'],c['font_style'])
        if row['index']>=100000 and key in targets and key not in selected and row['clean_control'] and row['recommended_for_standard_training'] and row['width']<=1740:
            selected[key]=row
        if len(selected)==len(targets):
            break
assert len(selected)==8
sheet=Image.new('RGB',(1800,8*140+65),'#eeeee9')
draw=ImageDraw.Draw(sheet)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',17)
draw.text((14,10),'TEMİZ KONTROL ÖRNEKLERİ • 200k setinin bir bölümü • Görüntüler doğal 48 px yükseklikte',font=font,fill='black')
for n,key in enumerate(targets):
    row=selected[key]
    y=60+n*140
    draw.text((14,y),f"{row['index']} | {key[0]} | {key[1]} | {row['categories']['content_type']}",font=font,fill='black')
    with Image.open(root/row['file_name']) as source:
        sheet.paste(source,(14,y+28))
    draw.text((14,y+90),row['text'],font=font,fill='black')
sheet.save(root/'official-preview-04-clean.jpg',quality=94)
(root/'clean-preview-selection.json').write_text(json.dumps([{'file_name':r['file_name'],'image_sha256':r['image_sha256'],'text':r['text']} for r in selected.values()],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Created clean style preview:',list(selected))
