from collections import Counter
from concurrent.futures import ProcessPoolExecutor
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, "/workspace/donut/synthdog/scripts")
import expand_tr_official as generation
import article_sampling
from finalize_tr_v5_buckets import choose_bucket

root = Path("/workspace/turkish-recognition-200k-v4")
old = Path("/workspace/turkish-recognition-100k-v3")
rows = [json.loads(line) for line in (root / "metadata.jsonl").read_text().splitlines()]
meta = json.loads((root / "metadata.json").read_text())
assert len(rows) == 200000 and meta["config"]["ctc_width_stride"] == 8
assert all(r["index"] == i for i, r in enumerate(rows))
preserved = 0
for i, line in enumerate((old / "metadata.jsonl").open()):
    before = json.loads(line)
    after = rows[i]
    comparable = {k: v for k, v in after.items() if k not in ("dataset_origin", "quality_flags", "recommended_for_standard_training")}
    comparable["categories"] = {k: v for k, v in after["categories"].items() if k not in generation.EXTRA_AXES}
    # The documented v5 capacity finalizer can only widen buckets.
    assert after["width_bucket"] >= before["width_bucket"]
    comparable["width_bucket"] = before["width_bucket"]
    assert comparable == before, i
    preserved += 1
assert preserved == 100000
source_report = article_sampling.audit_sources(rows[:100000], json.loads((root / "trwiki.sources.json").read_text()))
assert source_report == json.loads((old / "source-balance.json").read_text())
generation.dataset.write_json(root / "source-balance.json", source_report)

config = json.loads((root / "official-recipe.json").read_text())
fonts = generation.base.load_font_manifest(Path("/workspace/fonts/recognition-fonts.json"))
plan = generation.plan_samples(config, fonts, 100000, 20261016, 100000)
planned = json.loads((root / "official-planned-counts.json").read_text())
new_rows = rows[100000:]
for axis, counts in planned.items():
    assert Counter(r["categories"][axis] for r in new_rows) == counts, axis
assert Counter(r["categories"]["official_kind"] for r in new_rows) == dict.fromkeys(generation.official.KINDS.values(), 10000)

indices = set(int(i) for i in np.random.default_rng(61016).choice(100000, 256, replace=False))
seen = set()
for i, row in enumerate(new_rows):
    c = row["categories"]
    coverage = [
        ("font", row["font_sha256"]),
        ("kind_scan", c["official_kind"], c["scan_profile"]),
        ("confusable", c["official_kind"], c["targeted_group"]),
        ("capture", c["geometry"], c["exposure"], c["lighting_effect"]),
        ("bucket", row["width_bucket"]),
        ("style_mix", c["font_family"], c["mixed_typography"]),
        ("quality", tuple(row["quality_flags"])),
    ]
    for value in coverage:
        if value not in seen:
            indices.add(i)
            seen.add(value)
    if c["official_kind"] == "official_confusables_codes":
        tokens = row["source_text"].split(": ", 1)[1].split(" ; Belge:", 1)[0].split(" / ")
        assert Counter(tokens) == Counter(generation.official.GROUPS[c["targeted_group"]])
indices.update(sorted(range(100000), key=lambda i: len(new_rows[i]["text"]), reverse=True)[:20])

with ProcessPoolExecutor(max_workers=2, initializer=generation.initialize,
                         initargs=("/workspace/fonts/recognition-fonts.json", config, "/workspace/tr-v4-replay")) as pool:
    for number, row in enumerate(pool.map(generation.generate_one, [plan[i] for i in sorted(indices)], chunksize=8), 1):
        generation.add_quality(row)
        row["width_bucket"] = choose_bucket(row["width"], row["text"], meta["config"]["width_buckets"])
        if row != rows[row["index"]]:
            expected = rows[row["index"]]
            raise ValueError("Replay mismatch: " + str(row["index"]) + " " + str([k for k in set(row) | set(expected) if row.get(k) != expected.get(k)]))
        if number % 100 == 0:
            print("Replayed", number, "/", len(indices), flush=True)

assert {r["font_sha256"] for r in new_rows} == {f.sha256 for f in fonts}
assert all(set(Counter(r["categories"]["font_style"] for r in new_rows if r["categories"]["font_family"] == family).values()) == {5000}
           for family in ("Times New Roman", "Arial"))
punctuation = Counter(c for row in new_rows for c in row["text"] if c in ".,:;()/-@ ")
assert all(punctuation[c] > 0 for c in ".,:;()/-@ ")
assert json.loads((root / "audit.json").read_text())["duplicate_image_hashes"] == 0
report = {"passed": True, "samples": len(indices), "metadata_and_image_hashes_identical": True,
          "base_images_labels_and_splits_preserved": preserved, "base_metadata_changes_only_v5_buckets_and_added_annotations": True,
          "base_wikipedia_articles": source_report["articles_used"], "base_wikipedia_topics": source_report["topics_used"],
          "primary_font_files": len(fonts), "official_classes_each": 10000,
          "official_confusable_code_member_spans_checked": 10000,
          "all_official_marginal_quotas_match": True, "punctuation_counts_new": dict(punctuation),
          "coverage_keys": len(seen), "complete_component_loss_new": sum(r["removed_components"] > 0 for r in new_rows),
          "real_document_training_crops": 0}
generation.dataset.write_json(root / "replay-audit.json", report)
print(json.dumps(report), flush=True)
