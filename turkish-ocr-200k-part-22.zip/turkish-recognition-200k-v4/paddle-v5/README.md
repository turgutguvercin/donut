# Turkish PP-OCRv5_server_rec data configuration

Pinned official PaddleOCR commit: dab3fe35379033fdcb2d0e9572fac0b36c9a9ebf. Architecture: SVTR_HGNet / PPHGNetV2_B4.
`rec_tr_recommended.yml` uses quality-filtered training/validation lists.
`rec_tr_all.yml` includes ALL images, including intentionally ambiguous challenge crops.
Both use width 4096 and batch size 1 as a correctness-first starting point, not a Colab memory guarantee.
`rec_tr_w*.yml` each uses only ONE width subset; they do not automatically train all buckets together.
For efficient full-data training, implement a width-aware sampler and keep every bucket represented.

Global, NRTRHead and label encoders use max_text_length=256. The pinned NRTR encoder reserves
start/end tokens, so it accepts at most 254 actual characters. The official default 25 accepts 23.
Images remain 48px high with proportional widths; right padding does not squeeze long lines.
`d2s_train_image_shape` matches the selected width. Use a matching export/inference width policy.

Use the official Chinese/English PP-OCRv5_server_rec training checkpoint:
https://paddle-model-ecology.bj.bcebos.com/paddlex/official_pretrained_model/PP-OCRv5_server_rec_pretrained.pdparams
`pretrained_model` is deliberately unset until a correct weight-transfer step is performed.
The new UTF-8 dictionary changes character indices/class counts. Preserve compatible feature weights;
explicitly remap shared character rows or initialize affected CTC/NRTR output/embedding layers.
Simply swapping dictionaries or accepting unchecked shape mismatches is not a fine-tuning workflow.

RecAug/RecConAug are omitted because these images already contain measured degradation and long labels.
The upstream RecAug DOES contain blur; absence of blur in that operator is not the problem being addressed.
The accompanying audit executes checksum-pinned resize and CTC/NRTR encoding definitions on every sample.
It is not model training, an OCR accuracy test, or evidence that the model will fit every GPU.
