PaddleOCR PP-OCRv4 configuration reference: release/2.8 commit 2172c14bf65ceacf37a839ebbe61117a6339a865.
Place this dataset at ./train_data/turkish-camera-lighting-1000-v1, relative to the PaddleOCR checkout, or regenerate the configs with --data-dir.
rec_tr_all.yml covers ALL training and validation samples, right-padded to 4096. Its small batch size is a starting point.
rec_tr_w*.yml uses ONLY the matching width bucket and its validation subset. These are not seven automatic joint-training stages.
For efficient joint training, use batches of similar widths and retain all bucket lists; a custom bucket sampler is not installed here.
The default pretrained_model is null. Choose compatible pretrained weights for fine-tuning; a changed alphabet requires a compatible/new output head.
Do not use a static 320-pixel deployment/export input for these long lines. Configure matching dynamic/fixed width at inference.
Max label length is 256 in Global and NRTRHead. Use the supplied case-sensitive dictionary with use_space_char=true.
Extra RecAug/RecConAug are disabled because the samples already contain planned augmentations and concatenation could exceed label limits.
Validation below runs actual pinned preprocessing/label operators; it is not a model-training or OCR-accuracy test.
