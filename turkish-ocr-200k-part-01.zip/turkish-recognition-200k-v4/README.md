# Turkish recognition: 200,000 images, v4

Preserves all 100,000 v3 images/transcriptions/splits and adds **100,000 original official-style synthetic crops**.
This is line recognition data, not a document detection dataset. No real scanned/photographed document crops have been added.

| Split | Complete | Recommended | Challenge |
|---|---:|---:|---:|
| train | 180,000 | 151,402 | 28,598 |
| val | 10,000 | 8,391 | 1,609 |
| test | 10,000 | 8,410 | 1,590 |

Use **paddle-v5/rec_tr_recommended.yml** for the default filtered training/validation lists.
The complete lists retain deliberately ambiguous v3 crops. Quality flags are measurable proxies, not a human-readability guarantee.
The challenge lists contain excluded examples; they are not ordinary unambiguous training targets.

## Added official text

- official_verification: 10000
- official_footer_contact: 10000
- official_confusables_codes: 10000
- official_body_short: 10000
- official_heading: 10000
- official_date_reference: 10000
- official_subject: 10000
- official_amount: 10000
- official_body_long: 10000
- official_confusables_words: 10000

Times New Roman: 20,000 new images; Arial: 20,000; 18 other families share 60,000.
Each primary family has 5,000 examples per style: regular, bold, italic and bold italic.
Within-line mixed typography, underlines and varying glyph heights are included.
13 targeted confusable groups cover l/1/I/İ/ı/i, O/0, S/5, B/8, rn/m, cl/d, Turkish diacritics, 2021/202I and İl/İ1.
Dates, amounts, phone numbers, email/URL/KEP and verification fields use original generated values.
Reserved example.org contact domains are synthetic. Source template families recur across splits.

30,000 new crops use physical downsample→blur→noise→JPEG→upsample capture, with recorded glyph-height estimates.
V3's 400 Wikipedia articles across 20 topics and all previous visual categories remain intact.
source-balance.json describes the preserved Wikipedia portion; official-balance.json describes the added synthetic portion.
Balance is explicit marginal quotas, not all combinations equally frequent. Filtered-list distributions are reported separately.
Readable word forms: **52,442** overall.
No extra Wikipedia corpus was downloaded for this expansion.

## Measured PP-OCRv5 capacity

Height 48, width ≤4096; buckets 320/640/960/1280/1920/2560/4096.
Actual full PP-OCRv5_server_rec CPU forwards return 40/80/120/160/240/320/512 CTC steps: **width stride 8**.
The finalizer moved **11,092** samples into wider buckets without changing image bytes, labels or splits.
The Global/NRTR/encoder limit of 256 allows 254 real characters, reserving start/end tokens.
The actual longest label has 252 characters. The default 25 only allows 23.
Adjacent repeated characters are included in CTC capacity checks.

All 200,000 images passed decoding/hashes, UTF-8/NFC, actual font glyph coverage, quotas, split and crop checks.
All 200,000 passed pinned actual Paddle resize/CTC/NRTR operators, with no truncation or horizontal squeezing.
89 repository tests passed; **569** new samples replayed with exact metadata/image hashes.
All 100,000 base images/labels/splits were preserved. Duplicate image hashes: 0.
No model training, pretrained-model accuracy evaluation, or real-document accuracy claim.
The CPU shape probe uses random weights solely to measure architecture output dimensions.

## Sources, download and reproduction

See OFFICIAL-GUIDE.md for commands and limitations; official_document_references.json records the inspected public regulation.
Government PDF pages are not included as training images. Generated text follows observed field/typography conventions.
Keep LICENSE-DATASET.txt, trwiki.sources.json, font notices and provenance. No raw corpus or font binaries are distributed.
Generated images/labels: CC BY-SA 4.0; reproduction code: MIT; Paddle-derived configurations: Apache-2.0.

Use the published download_dataset.py helper for all ZIP parts and checksummed metadata reassembly.
Large metadata is stored in verified shards; manual ZIP extraction alone does not assemble metadata.jsonl.
V3 and v4 share 100,000 images. Do not combine their splits as independent datasets.
