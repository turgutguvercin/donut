# Turkish OCR recognition dataset — 100,000 images

100,000 RGB JPEG recognition crops and UTF-8 labels. Split: 90,000 train / 5,000 validation / 5,000 test.
20 primary font families, 5,000 images each; 62 real font files. Available styles are balanced within each family.
10 content classes, 10,000 each; 8 confusable groups, 1,250 each. See DATASET-GUIDE.md for all quotas and constraints.

Images: height 48, width 21–4096; labels 3–242 characters.
Width buckets: 320, 640, 960, 1280, 1920, 2560, 4096. Max Paddle label length: 256. Long lines retain proportions.
`labels.txt` and split/bucket lists contain relative image path, TAB, exact target text. Set PaddleOCR data_dir to this directory.
`paddle/rec_tr_all.yml` uses every train/val sample at width 4096. Each `rec_tr_w*.yml` uses only its matching bucket.
Set compatible pretrained weights for fine-tuning; generated configurations leave pretrained_model null.

All images were decoded and hashed, all labels checked for UTF-8/NFC and font/dictionary coverage, and all planned quotas audited.
Pinned PaddleOCR preprocessing and CTC/NRTR encoders were exercised on all 100,000 samples (paddle-preprocessing-audit.json).
Canonical target labels and source strings are disjoint between splits. Natural substrings can overlap.
Unique canonical labels: 72,320; repeated words/sentences have different rendered appearances within their split.
Duplicate image hashes: 0.

7,000 severe crops intentionally allow missing marks or letter fragments while preserving the original label. They are flagged potentially_ambiguous.
Optional *-without-severe-clips.txt files omit them. Labels ignore neighboring lines and decorative strokes.
Synthetic validation does not measure real-world OCR performance. No OCR model was trained for this delivery.

Reproduction code is in reproduce/, and exact dependency versions are in requirements-environment-lock.txt.
Generator commit: dd133a34a5d90e86d849a34d263f195fd299e24e. Seed: 20261014. Font hashes, corpus revisions and generator/image hashes are included.
Prepare the corpus from trwiki.sources.json with prepare_tr_corpus.py; acquire licensed fonts matching the catalog and update local font paths.
Use --count 100000 --seed 20261014 --font-manifest /path/to/fonts.json with the included generator.

Generated images/labels: CC BY-SA 4.0; attribution and terms: LICENSE-DATASET.txt.
Font binaries and the raw Wikipedia corpus are not included. Keep licenses/ and trwiki.sources.json when redistributing.
