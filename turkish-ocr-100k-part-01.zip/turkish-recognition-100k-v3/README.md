# Turkish OCR recognition — balanced vocabulary v3

100,000 RGB recognition images with exact UTF-8 labels: 90,000 train / 5,000 validation / 5,000 test.
This replacement version expands the earlier eight-article corpus to **400 Turkish Wikipedia articles across 20 topics**.
The generated labels contain **52,387 distinct readable word forms**
(50,261 in training), compared with 13,389 overall in v2.
Counts normalize Turkish case and apostrophes, exclude numeric/ID values and artificial confusable exercises,
and count inflections/names/abbreviations separately. They are surface forms, not dictionary lemmas.

## Balance and split isolation

- 60,000 natural-text images: 3,000 per topic and **150 per article**.
- Every article supplies 25 images in each natural-text class: ASCII word, Turkish word, short line, medium line, long sentence and extra-long sentence.
- Each topic has 18 training articles, one validation article and one test article: **360 / 20 / 20 articles**.
- Target and neighboring context articles are disjoint between splits. Canonical complete source/target strings are also disjoint. Individual words/substrings can overlap.
- Dates, prices, generated IDs and confusable exercises retain 10,000 images each.
- 20 font families × 5,000 images, with 62 real font files; available styles balanced within each family.
- Eight targeted confusable groups × 1,250; equal member frequency within each selected span.
- All v2 camera, lighting, typography, blur, curve, underline, spacing, backgrounds, printing, occlusion and crop-error quotas remain.

See source-balance.json, category-counts.json and pair-counts.json. Balance refers to explicit marginal quotas;
not every factor combination is equally frequent. Common words can recur; word counts are not forced equal.
Article topics are editorial selections, not a universal or exhaustive Turkish-language distribution.

## PaddleOCR

Images are height **48**, proportional width 12–4096, with buckets 320 / 640 / 960 / 1280 / 1920 / 2560 / 4096.
Maximum label length is 256. Long lines are not squeezed to width 320. Set data_dir to this directory.
paddle/rec_tr_all.yml uses all samples; per-width configs each use their own subset. Set suitable pretrained weights before fine-tuning.
All Turkish alphabet letters appear in training. Foreign letters ć and ň occur only in held-out labels;
character inventories and frequencies are recorded in vocabulary-report.json.

## Verification

All 100,000 images passed decoding, hash, UTF-8/NFC label, actual font-run, dictionary, category/source quota,
split, clipping, geometry, shadow and CTC-capacity checks. Duplicate image hashes: 0.
All samples passed actual pinned PaddleOCR resizing and CTC/NRTR label encoding without dropped characters or horizontal squeezing.
Fresh replay matched exact image hashes and metadata for 940 samples, including all source articles and font files.
81 repository tests pass. No OCR model training or real-world accuracy is claimed.

Severe crops retain source labels even when marks/fragments disappear. potentially_ambiguous and optional *-without-severe-clips.txt files identify/omit them.
The 14 controlled crops in comparisons/ are outside the 100,000 samples. topics-preview-*.jpg show actual crops from all topics.
Real independently sourced detector crops are still needed for deployment evaluation. Do not mix versions and assume split isolation.

## Reproduction and licensing

Source commit: 6fbcfa37f2d08c11a28efd1132b813216a3ece0a. Seed: 20261014. Exact generator/font hashes, source revisions,
environment lock, configs and reproduction source are included. See VOCABULARY-GUIDE.md for commands.
Replay corpus with prepare_tr_balanced_corpus.py --manifest trwiki.sources.json, using licensed fonts matching the catalog.
Run generate_tr_dataset.py with config_tr_recognition_balanced.json, the replayed corpus, count 100000 and seed 20261014.

Generated images and labels: **CC BY-SA 4.0**, attributed to Turkish Wikipedia contributors through trwiki.sources.json.
Retain LICENSE-DATASET.txt, the source manifest and licenses/. No raw corpus or font binaries are included.
Reproduction code: MIT. Paddle-derived configs: Apache-2.0. The controlled comparison sentence is authored and CC BY-SA 4.0.
