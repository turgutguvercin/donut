# Turkish OCR recognition — full 100,000-image dataset v2

100,000 RGB JPEG recognition crops and exact UTF-8 labels. Split: 90,000 train / 5,000 validation / 5,000 test.
This full replacement version adds explicit side-camera perspective, exposure and shadows throughout the balanced recipe.
The earlier v1 remains separately available. Do not concatenate its splits with v2 and assume split isolation across versions.

| Factor | Full-dataset counts |
|---|---|
| Geometry | 40,000 frontal; 20,000 skew; 10,000 each left/mild, right/mild, left/strong, right/strong |
| Exposure | 50,000 normal; 12,500 each low light, underexposed, bright, overexposed |
| Lighting | 50,000 none; 12,500 each gradient, soft shadow, hard shadow, partial shadow |
| Font family | 20 families × 5,000 images; 62 real font files |
| Content | Ten content classes × 10,000, including long sentences and explicit confusables |
| Confusables | Eight groups × 1,250; each targeted member occurs once per selected span |

All other curve, font style/size, Turkish case, decoration, crop, spacing, blur, printing and occlusion factors retain their documented quotas.
See category-counts.json, planned-counts.json, pair-counts.json and categories.csv for the exact distributions.
Balance means weighted marginal quotas; combinations are sampled under the documented readability constraints.

From a camera on the right, the left end is smaller and the right end larger, with horizontal foreshortening as well as height taper.
Exposure and shadows affect text, paper and neighboring lines together. Low light includes sensor noise.
The 14 crops in comparisons/ repeat an authored Turkish sentence for controlled visual inspection; they are outside the 100,000 training/validation/test samples.

Images: height 48, proportional width 17–4096; labels 3–242 characters.
Width buckets: 320, 640, 960, 1280, 1920, 2560, 4096. Max Paddle label length: 256. Long lines are not squeezed to 320.
Set PaddleOCR data_dir to this directory. paddle/rec_tr_all.yml uses all samples; each rec_tr_w*.yml uses only its matching width bucket.
Configs start with pretrained_model=null; set appropriate checkpoint weights before fine-tuning.

All 100,000 images and UTF-8/NFC labels were decoded, hashed, checked against actual font-run/dictionary coverage,
planned quotas, split grouping, clipping bounds, camera direction, shadow overlap and CTC capacity.
Pinned actual PaddleOCR preprocessing/encoding passed on all 100,000 without dropped characters, truncated labels or horizontal squeezing.
Duplicate image hashes: 0. Unique canonical labels: 72,273.
Canonical source/target strings are disjoint between splits within this dataset; natural substrings can overlap.
70 repository tests pass. No OCR model was trained and synthetic audits do not establish real-world accuracy.

7,000 severe crops deliberately retain source labels despite missing marks/letter fragments.
They are flagged potentially_ambiguous and optional *-without-severe-clips.txt files omit them.

Source commit: 1a0763dc78c0d69c14b5b0591dff8ffdb3ae75b4. Seed: 20261014.
Exact generator hashes, source revisions, font hashes/licenses, environment lock and reproduction source are included.
To reproduce, clone that repository commit, prepare corpus text from trwiki.sources.json, acquire licensed fonts matching the catalog,
and update the catalog's local paths. From synthdog/:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python scripts/generate_tr_dataset.py \
  --config config_tr_recognition_camera.json --font-manifest /path/to/fonts.json \
  --output outputs/turkish-recognition-100k-v2 --count 100000 --seed 20261014 --workers 4
python scripts/prepare_paddle_tr.py --dataset outputs/turkish-recognition-100k-v2 \
  --cache /tmp/paddleocr-reference --data-dir ./train_data/turkish-recognition-100k-v2
```

Generated images and labels: CC BY-SA 4.0, attributed to Turkish Wikipedia contributors with exact revision links.
Retain LICENSE-DATASET.txt, trwiki.sources.json and licenses/ when redistributing. The controlled comparison sentence is authored and CC BY-SA 4.0.
No raw Wikipedia text or font binaries are included. Reproduction code: MIT. Paddle-derived configs: Apache-2.0.
